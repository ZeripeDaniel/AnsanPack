package com.ansan.ansanpack.item;

import com.ansan.ansanpack.client.level.LocalPlayerStatData;
import com.ansan.ansanpack.config.StatDatabaseManager;
import net.minecraft.server.TickTask;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResultHolder;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.UseAnim;
import net.minecraft.world.level.Level;

public class CustomPotionItem extends Item {

    private final float healPercentage;
    private static final int USE_DURATION = 20; // 1초 (20 ticks)
    private static final int COOLDOWN = 200;     // 10초 (200 ticks)

    public CustomPotionItem(Properties properties, float healPercentage) {
        super(properties);
        this.healPercentage = healPercentage;
    }

    @Override
    public InteractionResultHolder<ItemStack> use(Level level, Player player, InteractionHand hand) {
        ItemStack itemstack = player.getItemInHand(hand);

        if (!player.getCooldowns().isOnCooldown(this)) {
            player.startUsingItem(hand);

            if (!level.isClientSide) {
                level.getServer().tell(new TickTask(USE_DURATION, () -> {
                    float maxHealth = player.getMaxHealth();
                    float healAmount = maxHealth * healPercentage;

                    // 본인 회복
                    player.heal(healAmount);
                    level.playSound(null, player.getX(), player.getY(), player.getZ(),
                            SoundEvents.HONEY_DRINK, SoundSource.PLAYERS, 0.5F,
                            level.getRandom().nextFloat() * 0.1F + 0.9F);

                    player.getCooldowns().addCooldown(this, COOLDOWN);
                    if (!player.getAbilities().instabuild) {
                        itemstack.shrink(1);
                    }

                    // 힐 공유 로직
                    if (player instanceof ServerPlayer serverPlayer && level instanceof ServerLevel serverLevel) {
                        int intelligence = StatDatabaseManager.getStats(serverPlayer.getUUID()).getIntelligence(); // 서버에서 가져옴

                        float shareRate = 0.1f + (intelligence * 0.01f);
                        if (shareRate > 0.4f) shareRate = 0.4f;

                        float sharedHeal = healAmount * shareRate;

                        for (ServerPlayer other : serverLevel.getPlayers(player -> player != serverPlayer &&
                                player.distanceTo(serverPlayer) <= 15)) {
                            other.heal(sharedHeal);
                            // 필요 시: 이펙트나 메시지 출력 가능
                        }
                    }

                }));
            }

            return InteractionResultHolder.consume(itemstack);
        }

        return InteractionResultHolder.fail(itemstack);
    }

    @Override
    public int getUseDuration(ItemStack stack) {
        return USE_DURATION;
    }

    @Override
    public UseAnim getUseAnimation(ItemStack stack) {
        return UseAnim.EAT;
    }
}
