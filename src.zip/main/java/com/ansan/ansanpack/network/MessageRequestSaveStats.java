package com.ansan.ansanpack.network;

import com.ansan.ansanpack.config.StatDatabaseManager;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.server.level.ServerPlayer;
import net.minecraftforge.network.NetworkEvent;

import java.util.function.Supplier;

/**
 * 클라이언트 → 서버: 스탯 저장 요청
 */
public class MessageRequestSaveStats {

    public MessageRequestSaveStats() {}

    public static MessageRequestSaveStats decode(FriendlyByteBuf buf) {
        return new MessageRequestSaveStats();
    }

    public void encode(FriendlyByteBuf buf) {}

    public void handle(Supplier<NetworkEvent.Context> ctx) {
        ctx.get().enqueueWork(() -> {
            ServerPlayer player = ctx.get().getSender();
            if (player == null) return;

            StatDatabaseManager.saveStats(player.getUUID(), player.getName().getString());
        });
        ctx.get().setPacketHandled(true);
    }
}
