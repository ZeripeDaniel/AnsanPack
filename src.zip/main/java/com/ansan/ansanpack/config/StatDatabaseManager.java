package com.ansan.ansanpack.config;

import com.ansan.ansanpack.client.level.LocalPlayerStatData;

import java.sql.*;
import java.util.Properties;
import java.util.UUID;

public class StatDatabaseManager {

    private static Connection getConnection() throws SQLException {
        Properties props = UpgradeConfigManager.loadDbProps(); // ✅ 재사용
        String url = "jdbc:mysql://" + props.getProperty("db.host") + ":" +
                props.getProperty("db.port") + "/" +
                props.getProperty("db.database") +
                "?serverTimezone=Asia/Seoul&useSSL=false&allowPublicKeyRetrieval=true";

        return DriverManager.getConnection(url, props.getProperty("db.user"), props.getProperty("db.password"));
    }

    // ✅ 스탯 저장
    public static void saveStats(UUID uuid, String playerName) {
        LocalPlayerStatData data = LocalPlayerStatData.INSTANCE;

        try (Connection conn = getConnection()) {
            PreparedStatement stmt = conn.prepareStatement(
                    "INSERT INTO player_stats (uuid, player_name, str, agi, intel, luck, available_ap) " +
                            "VALUES (?, ?, ?, ?, ?, ?, ?) " +
                            "ON DUPLICATE KEY UPDATE player_name=?, str=?, agi=?, intel=?, luck=?, available_ap=?"
            );
            stmt.setString(1, uuid.toString());
            stmt.setString(2, playerName);
            stmt.setInt(3, data.getStat("str"));
            stmt.setInt(4, data.getStat("agi"));
            stmt.setInt(5, data.getStat("int"));
            stmt.setInt(6, data.getStat("luck"));
            stmt.setInt(7, data.getAvailableAP());

            // UPDATE용
            stmt.setString(8, playerName);
            stmt.setInt(9, data.getStat("str"));
            stmt.setInt(10, data.getStat("agi"));
            stmt.setInt(11, data.getStat("int"));
            stmt.setInt(12, data.getStat("luck"));
            stmt.setInt(13, data.getAvailableAP());

            stmt.executeUpdate();
        } catch (SQLException e) {
            throw new RuntimeException("[AnsanPack] 스탯 저장 실패: " + e.getMessage(), e);
        }
    }

    // ✅ 스탯 불러오기
    public static void loadStats(UUID uuid) {
        try (Connection conn = getConnection()) {
            PreparedStatement stmt = conn.prepareStatement(
                    "SELECT * FROM player_stats WHERE uuid = ?"
            );
            stmt.setString(1, uuid.toString());

            ResultSet rs = stmt.executeQuery();
            if (rs.next()) {
                LocalPlayerStatData.INSTANCE.loadFromSQL(
                        rs.getInt("str"),
                        rs.getInt("agi"),
                        rs.getInt("intel"),
                        rs.getInt("luck"),
                        rs.getInt("available_ap")
                );
            }
        } catch (SQLException e) {
            throw new RuntimeException("[AnsanPack] 스탯 불러오기 실패: " + e.getMessage(), e);
        }
    }
}
